__author__ = "Henry Ginn"
__date__ = "2023/06/05"
__version__ = "1.1.2"

from . import defaults
from . import utils
from . import plotting

defaults.docs()
